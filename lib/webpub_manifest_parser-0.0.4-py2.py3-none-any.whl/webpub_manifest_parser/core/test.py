import logging

from requests.auth import HTTPBasicAuth

from webpub_manifest_parser.odl.parsers import ODLDocumentParserFactory
from webpub_manifest_parser.opds2.registry import OPDS2LinkRelationsRegistry
from webpub_manifest_parser.utils import first_or_default

parser_factory = ODLDocumentParserFactory()
parser = parser_factory.create()
url = "https://market.feedbooks.com/api/libraries/harvest.json"
page = 1

with open("output.csv", "w") as output_file:
    output_file.write(
        "{0}\t{1}\t{2}\t{3}\t{4}\n".format(
            "url", "page", "title", "identifier", "oa_acquisition_link"
        )
    )
    while True:
        try:
            print("Started parsing {0}".format(url))

            feed = parser.parse_url(url, "utf-8 ", HTTPBasicAuth("262", "abcde12356"))

            print("Finished parsing {0}".format(url))

            next_link = first_or_default(feed.links.get_by_rel("next"))

            for publication in feed.publications:
                identifier = publication.metadata.identifier
                title = publication.metadata.title
                description = publication.metadata.description
                oa_acquisition_link = first_or_default(
                    publication.links.get_by_rel(
                        OPDS2LinkRelationsRegistry.OPEN_ACCESS.key
                    )
                )

                output_file.write(
                    "{0}\t{1}\t{2}\t{3}\t{4}\n".format(
                        url,
                        page,
                        title.encode("utf-8").replace("&#39;", "'"),
                        identifier,
                        oa_acquisition_link.href
                        if oa_acquisition_link is not None
                        else "",
                        # description.encode("utf-8").replace("\n", "")
                    )
                )

            if not next_link:
                break

            url = next_link.href
            page += 1
        except Exception:
            logging.exception(
                "An unexpected error occurred during parsing {0}".format(url)
            )
